package toolsinc.bank.pfbalancecheck.epfbalancecheck.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import toolsinc.bank.pfbalancecheck.epfbalancecheck.R;
import toolsinc.bank.pfbalancecheck.epfbalancecheck.helper.Utils;
import toolsinc.bank.pfbalancecheck.epfbalancecheck.model.CalculateEMI;
import toolsinc.bank.pfbalancecheck.epfbalancecheck.model.EMIModel;
import toolsinc.bank.pfbalancecheck.epfbalancecheck.splashexit.Utils.Common;

public class EmiCalcActivity extends AppCompatActivity implements View.OnClickListener {
    private TextView mBtnCalculateEMI;
    private TextView mBtnReset;
    private double mEMI;
    private EditText mEdtLoanAmount;
    private EditText mEdtLoanTenure;
    private EditText mEdtProcessingFee;
    private EditText mEdtRateOfInterest;
    private double mProcessingFeeAmount;
    private ScrollView mScrollContent;
    private double mTotalInterest;
    private double mTotalPayment;
    private TextView mTvEmiMonthlyPayment;
    private TextView mTvProcessingFee;
    private TextView mTvTotalInterest;
    private TextView mTvTotalPayment;
    private TextView tvYear, tvMonth;
    private LinearLayout llYear, llMonth;
    private int selItem = 0;
    private FrameLayout adMobView;

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_emicalc);

        adMobView = (FrameLayout) findViewById(R.id.adMobView);
        Common.NativeBanner(EmiCalcActivity.this, adMobView, "item_native");

        ImageView ivBack = findViewById(R.id.ivBack);
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        init();
    }

    private void init() {
        this.mTvEmiMonthlyPayment = (TextView) findViewById(R.id.tvEmiMonthlyPayment);
        this.mTvTotalInterest = (TextView) findViewById(R.id.tvTotalIntrest);
        this.mTvTotalPayment = (TextView) findViewById(R.id.tvTotalPayment);
        this.mTvProcessingFee = (TextView) findViewById(R.id.tvProcessingFee);
        this.mEdtLoanAmount = (EditText) findViewById(R.id.edtLoanAmount);
        this.mEdtRateOfInterest = (EditText) findViewById(R.id.edtRateOfInterest);
        this.mEdtLoanTenure = (EditText) findViewById(R.id.edtLoanTenure);
        llYear = (LinearLayout) findViewById(R.id.llYear);
        llMonth = (LinearLayout) findViewById(R.id.llMonth);
        this.tvYear = (TextView) findViewById(R.id.tvYear);
        this.tvMonth = (TextView) findViewById(R.id.tvMonth);
        tvYear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selItem = 0;
                llYear.setBackgroundResource(R.drawable.bg_eq);
                llMonth.setBackgroundResource(R.drawable.bg_edit);
                tvYear.setTextColor(getResources().getColor(R.color.white));
                tvMonth.setTextColor(getResources().getColor(R.color.light_gray));
            }
        });
        tvMonth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selItem = 1;
                llMonth.setBackgroundResource(R.drawable.bg_eq);
                llYear.setBackgroundResource(R.drawable.bg_edit);
                tvMonth.setTextColor(getResources().getColor(R.color.white));
                tvYear.setTextColor(getResources().getColor(R.color.light_gray));
            }
        });

        this.mEdtProcessingFee = (EditText) findViewById(R.id.edtProcessingFee);
        this.mBtnCalculateEMI = (TextView) findViewById(R.id.btnCalculateEMI);
        this.mBtnReset = (TextView) findViewById(R.id.btnReset);
        this.mBtnCalculateEMI.setOnClickListener(this);
        this.mBtnReset.setOnClickListener(this);
        this.mScrollContent = (ScrollView) findViewById(R.id.scrollContent);
        resetFinalValues();
    }

    private boolean isAllaFieldsValid() {
        if (this.mEdtLoanAmount.getText().toString().length() == 0) {
            this.mEdtLoanAmount.setError("Please enter Loan Amount.");
            return false;
        } else if (this.mEdtLoanAmount.getText().toString().equalsIgnoreCase("0")) {
            this.mEdtLoanAmount.setError("Amount should be greater than 0.");
            return false;
        } else if (this.mEdtRateOfInterest.getText().toString().length() == 0) {
            this.mEdtRateOfInterest.setError("Please enter Interest.");
            return false;
        } else if (this.mEdtRateOfInterest.getText().toString().equalsIgnoreCase("0")) {
            this.mEdtRateOfInterest.setError("Interest should be greater than 0.");
            return false;
        } else if (this.mEdtLoanTenure.getText().toString().length() == 0) {
            this.mEdtLoanTenure.setError("Please enter Loan Tenure.");
            return false;
        } else if (!this.mEdtLoanTenure.getText().toString().equalsIgnoreCase("0")) {
            return true;
        } else {
            this.mEdtLoanTenure.setError("Loan Tenure should be greater than 0.");
            return false;
        }
    }

    public void clickCalculateEMI() {
        Utils.hideSoftKeyboard(EmiCalcActivity.this);
        if (isAllaFieldsValid()) {
            this.mScrollContent.post(new Runnable() {
                @Override
                public void run() {
                    lambda$clickCalculateEMI$0$EMICalculationFragment();
                }
            });
        }
    }

    final /* synthetic */ void lambda$clickCalculateEMI$0$EMICalculationFragment() {
        if (EmiCalcActivity.this != null) {
            this.mScrollContent.smoothScrollTo(0, findViewById(R.id.content_view).getBottom());
        }
        calculateEMI();
    }

    private EMIModel calculateEMI() {
        if (!isAllaFieldsValid()) {
            return null;
        }
        double parseDouble = Double.parseDouble(this.mEdtLoanAmount.getText().toString());
        double parseDouble2 = Double.parseDouble(this.mEdtRateOfInterest.getText().toString());
        double parseDouble3 = Double.parseDouble(this.mEdtLoanTenure.getText().toString());
        String obj = this.mEdtProcessingFee.getText().toString();
        double d = 0.0d;
        if (!obj.isEmpty()) {
            d = Double.parseDouble(obj);
        }
        double d2 = d;
        double d3 = parseDouble2;
        double d4 = selItem == 0 ? 12.0d * parseDouble3 : parseDouble3;
        this.mEMI = CalculateEMI.getCalculatedEMIValue(parseDouble, d3, d4).doubleValue();
        this.mTotalInterest = CalculateEMI.calculateInterest(parseDouble, d3, d4);
        this.mProcessingFeeAmount = CalculateEMI.calculateProcessingFee(parseDouble, d2);
        this.mTotalPayment = CalculateEMI.calculateTotalAmount(parseDouble, d3, d4);
        this.mTvEmiMonthlyPayment.setText(Utils.getFormattedCurrency(EmiCalcActivity.this, this.mEMI, 0));
        this.mTvTotalInterest.setText(Utils.getFormattedCurrency(EmiCalcActivity.this, this.mTotalInterest, 0));
        this.mTvTotalPayment.setText(Utils.getFormattedCurrency(EmiCalcActivity.this, this.mTotalPayment, 0));
        this.mTvProcessingFee.setText(Utils.getFormattedCurrency(EmiCalcActivity.this, this.mProcessingFeeAmount, 0));
        EMIModel eMIModel = new EMIModel();
        eMIModel.setPrincipalAmount(Double.valueOf(parseDouble));
        eMIModel.setLoanTenure(Double.valueOf(parseDouble3));
        eMIModel.setRoiPercentage(parseDouble2);
        eMIModel.setProcessFeePercentage(d2);
        eMIModel.setEmi(this.mEMI);
        eMIModel.setTotalInterestAmount(this.mTotalInterest);
        eMIModel.setTotalPaymentAmount(this.mTotalPayment);
        eMIModel.setProcessFeeAmount(this.mProcessingFeeAmount);
        return eMIModel;
    }

    public void reset() {
        this.mEdtLoanAmount.setText("");
        this.mEdtRateOfInterest.setText("");
        this.mEdtLoanTenure.setText("");
        this.mEdtProcessingFee.setText("");
        resetFinalValues();
        this.mScrollContent.post(new Runnable() {
            @Override
            public void run() {
                lambda$reset$1$EMICalculationFragment();
            }
        });
    }

    final /* synthetic */ void lambda$reset$1$EMICalculationFragment() {
        this.mScrollContent.fullScroll(33);
    }

    private void resetFinalValues() {
        this.mTvEmiMonthlyPayment.setText(Utils.getFormattedCurrency(EmiCalcActivity.this, 0.0d));
        this.mTvTotalInterest.setText(Utils.getFormattedCurrency(EmiCalcActivity.this, 0.0d));
        this.mTvTotalPayment.setText(Utils.getFormattedCurrency(EmiCalcActivity.this, 0.0d));
        this.mTvProcessingFee.setText(Utils.getFormattedCurrency(EmiCalcActivity.this, 0.0d));
    }


    public void onClick(View view) {
        if (view == this.mBtnCalculateEMI) {
            clickCalculateEMI();
        } else if (view == this.mBtnReset) {
            reset();
        }
    }
}
