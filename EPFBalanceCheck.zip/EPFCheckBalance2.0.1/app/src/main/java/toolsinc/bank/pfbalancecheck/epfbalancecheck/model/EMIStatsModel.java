package toolsinc.bank.pfbalancecheck.epfbalancecheck.model;

import java.util.ArrayList;

public class EMIStatsModel {
    public Double balancePrincipalAmount;
    public Double interestPerMonthAmount;
    public ArrayList<EMIStatsModel> listMonthlyStats = new ArrayList();
    public String month_or_year;
    public Double principalPerMonthAmount;

    public EMIStatsModel(String str, double d, double d2, double d3) {
        this.month_or_year = str;
        this.interestPerMonthAmount = Double.valueOf(d);
        this.principalPerMonthAmount = Double.valueOf(d2);
        this.balancePrincipalAmount = Double.valueOf(d3);
    }

    public EMIStatsModel() {

    }
}
