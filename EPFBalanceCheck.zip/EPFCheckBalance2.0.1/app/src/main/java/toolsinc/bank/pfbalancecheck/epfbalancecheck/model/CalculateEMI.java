package toolsinc.bank.pfbalancecheck.epfbalancecheck.model;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

import toolsinc.bank.pfbalancecheck.epfbalancecheck.helper.Utils;

public class CalculateEMI {
    public static double calculateProcessingFee(double d, double d2) {
        return d2 > 0.0d ? (d2 * d) / 100.0d : 0.0d;
    }

    public static Double getCalculatedEMIValue(double d, double d2, double d3) {
        d2 = (d2 / 12.0d) / 100.0d;
        DecimalFormat decimalFormat = new DecimalFormat("#.##");
        decimalFormat.setDecimalFormatSymbols(DecimalFormatSymbols.getInstance(Locale.ENGLISH));
        d *= d2;
        d2 += 1.0d;
        return Double.valueOf(Double.parseDouble(decimalFormat.format((d * Math.pow(d2, d3)) / (Math.pow(d2, d3) - 1.0d))));
    }

    public static double calculateInterest(double d, double d2, double d3) {
        return (getCalculatedEMIValue(d, d2, d3).doubleValue() * d3) - d;
    }

    public static double calculateTotalAmount(double d, double d2, double d3) {
        return getCalculatedEMIValue(d, d2, d3).doubleValue() * d3;
    }

    public static List<EMIStatsModel> getEmiListAsPerMonth(double d, double d2, double d3, long j) {
        List<EMIStatsModel> arrayList = new ArrayList();
        Calendar instance = Calendar.getInstance(Locale.ENGLISH);
        instance.setTimeInMillis(j);
        instance.add(2, 1);
        double d4 = (d2 / 12.0d) / 100.0d;
        double doubleValue = getCalculatedEMIValue(d, d2, d3).doubleValue();
        double d5 = d;
        long j2 = 1;
        while (((double) j2) <= d3) {
            double d6 = d5 * d4;
            double d7 = doubleValue - d6;
            d5 = Math.abs(d5 - d7);
            EMIStatsModel eMIStatsModel = new EMIStatsModel();
            double d8 = d4;
            eMIStatsModel.month_or_year = Utils.getFormattedDate(Utils.MMM_YY, instance.getTimeInMillis());
            eMIStatsModel.interestPerMonthAmount = Double.valueOf(d6);
            eMIStatsModel.principalPerMonthAmount = Double.valueOf(d7);
            eMIStatsModel.balancePrincipalAmount = Double.valueOf(d5);
            arrayList.add(eMIStatsModel);
            instance.set(2, instance.get(2) + 1);
            int i = 2;
            int i2 = 1;
            j2++;
            d4 = d8;
        }
        return arrayList;
    }

}
