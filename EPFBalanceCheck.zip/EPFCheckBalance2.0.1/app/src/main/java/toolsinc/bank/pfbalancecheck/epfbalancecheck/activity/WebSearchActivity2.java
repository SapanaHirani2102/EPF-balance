package toolsinc.bank.pfbalancecheck.epfbalancecheck.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.u.securekeys.SecureEnvironment;

import toolsinc.bank.pfbalancecheck.epfbalancecheck.R;
import toolsinc.bank.pfbalancecheck.epfbalancecheck.splashexit.Utils.Common;

public class WebSearchActivity2 extends Activity {

    private WebView webView;
    private int pos;
    private TextView txtName;
    private ProgressBar progress_bar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_search);
        pos = getIntent().getIntExtra("position", 0);
        progress_bar = findViewById(R.id.progress_bar);

//        FrameLayout adMobView = (FrameLayout) findViewById(R.id.adMobView);
//        Common.NativeBanner(this, adMobView, "item_native");

        ImageView ivBack = (ImageView) findViewById(R.id.ivBack);
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        txtName = (TextView) findViewById(R.id.txtName);
        bindView();
    }

    @Override
    public void onBackPressed() {
        setResult(RESULT_OK);
        finish();
    }

    private void bindView() {
        webView = (WebView) findViewById(R.id.webView);
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);// enable javascript
        webSettings.setJavaScriptCanOpenWindowsAutomatically(true);

        webView.setInitialScale(1);
        webView.getSettings().setLoadWithOverviewMode(true);
        webView.getSettings().setUseWideViewPort(true);
        webView.setScrollBarStyle(WebView.SCROLLBARS_OUTSIDE_OVERLAY);
        webView.setScrollbarFadingEnabled(true);
        webView.getSettings().setBuiltInZoomControls(true);
        webView.getSettings().setDisplayZoomControls(false);

        webView.setWebViewClient(new WebViewClient() {

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {

                if (progress_bar.getVisibility() == View.GONE) {
                    progress_bar.setVisibility(View.VISIBLE);
                }

                if (url.startsWith("http:") || url.startsWith("https:")) {
                    return false;
                }
                // Otherwise allow the OS to handle things like tel, mailto, etc.
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(intent);
                return true;
            }

            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                Toast.makeText(WebSearchActivity2.this, description, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (progress_bar.getVisibility() == View.VISIBLE) {
                    progress_bar.setVisibility(View.GONE);
                }
            }
        });
        if (Common.CheckNet(WebSearchActivity2.this)) {
            if (pos == 0) {
                txtName.setText("Check Your EPF");
                webView.loadUrl("https://www.epfindia.gov.in/site_en/index.php");
            } else if (pos == 1) {
                txtName.setText("Knowing the Claim Status");
                webView.loadUrl("https://www.epfindia.gov.in/site_en/KYCS.php");
            } else if (pos == 2) {
                txtName.setText("Online Transfer Claims Portal (OTCP)");
                webView.loadUrl("https://www.epfindia.gov.in/site_en/OTCP_ForEmployers.php");
            } else if (pos == 3) {
                txtName.setText("Member Passbook");
                webView.loadUrl("https://passbook.epfindia.gov.in/MemberPassBook/Login.jsp");
            } else if (pos == 4) {
                txtName.setText("Download Claim Form");
                webView.loadUrl("https://www.epfindia.gov.in/site_en/Downloads.php?id=sm8_index");
            } else if (pos == 5) {
                txtName.setText("Multiple PF Accounts of an Employee");
                webView.loadUrl("http://oeoea.epfoservices.com/UANDEDUP/");
            } else if (pos == 6) {
                txtName.setText("E-Passbook");
                webView.loadUrl("https://passbook.epfindia.gov.in/MemberPassBook/Login.jsp");
            } else if (pos == 7) {
            } else if (pos == 8) {
                txtName.setText("Downloads");
                webView.loadUrl("https://www.epfindia.gov.in/site_en/Downloads.php?id=sm8_index");
            } else if (pos == 9) {
                txtName.setText("Recruitments");
                webView.loadUrl("https://www.epfindia.gov.in/site_en/Recruitments.php?id=sm9_index");
            } else if (pos == 10) {
                txtName.setText("Tenders");
                webView.loadUrl("https://www.epfindia.gov.in/site_en/Tender_Auction.php?id=sm10_index");
            } else if (pos == 11) {
                txtName.setText("Right To Information");
                webView.loadUrl("https://www.epfindia.gov.in/site_en/RTI.php?id=sm12_index");
            } else if (pos == 12) {
                txtName.setText("Contact US");
                webView.loadUrl("https://www.epfindia.gov.in/site_en/Contact_us.php");
            } else if (pos == 13) {
                txtName.setText("Link UAN With Aadhar");
                webView.loadUrl("https://iwu.epfindia.gov.in/eKYC/");
            }
        } else {
            if (pos == 0) {
                txtName.setText("Check Your EPF");
                webView.loadUrl("https://www.epfindia.gov.in/site_en/index.php");
            } else if (pos == 1) {
                txtName.setText("Knowing the Claim Status");
                webView.loadUrl("https://www.epfindia.gov.in/site_en/KYCS.php");
            } else if (pos == 2) {
                txtName.setText("Online Transfer Claims Portal (OTCP)");
                webView.loadUrl("https://www.epfindia.gov.in/site_en/OTCP_ForEmployers.php");
            } else if (pos == 3) {
                txtName.setText("Member Passbook");
                webView.loadUrl("https://passbook.epfindia.gov.in/MemberPassBook/Login.jsp");
            } else if (pos == 4) {
                txtName.setText("Download Claim Form");
                webView.loadUrl("https://www.epfindia.gov.in/site_en/Downloads.php?id=sm8_index");
            } else if (pos == 5) {
                txtName.setText("Multiple PF Accounts of an Employee");
                webView.loadUrl("http://oeoea.epfoservices.com/UANDEDUP/");
            } else if (pos == 6) {
                txtName.setText("E-Passbook");
                webView.loadUrl("https://passbook.epfindia.gov.in/MemberPassBook/Login.jsp");
            } else if (pos == 7) {
                txtName.setText("Downloads");
                webView.loadUrl("https://www.epfindia.gov.in/site_en/Downloads.php?id=sm8_index");
            } else if (pos == 8) {
                txtName.setText("Recruitments");
                webView.loadUrl("https://www.epfindia.gov.in/site_en/Recruitments.php?id=sm9_index");
            } else if (pos == 9) {
                txtName.setText("Tenders");
                webView.loadUrl("https://www.epfindia.gov.in/site_en/Tender_Auction.php?id=sm10_index");
            } else if (pos == 10) {
                txtName.setText("Right To Information");
                webView.loadUrl("https://www.epfindia.gov.in/site_en/RTI.php?id=sm12_index");
            } else if (pos == 11) {
                txtName.setText("Contact US");
                webView.loadUrl("https://www.epfindia.gov.in/site_en/Contact_us.php");
            } else if (pos == 12) {
                txtName.setText("Link UAN With Aadhar");
                webView.loadUrl("https://iwu.epfindia.gov.in/eKYC/");
            }
        }

    }

}
