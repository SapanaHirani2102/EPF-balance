package toolsinc.bank.pfbalancecheck.epfbalancecheck.activity;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.u.securekeys.SecureEnvironment;

import toolsinc.bank.pfbalancecheck.epfbalancecheck.R;
import toolsinc.bank.pfbalancecheck.epfbalancecheck.splashexit.Utils.Common;

public class WebSearchActivity extends Activity {

    private WebView webView;
    private int pos;
    private TextView txtName;
    private Dialog dialog1;
    private ProgressBar progress_bar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_search);

        dialog1 = new Dialog(WebSearchActivity.this, R.style.DialogCustomTheme);
        dialog1.setContentView(R.layout.dialog_ad);
        dialog1.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        dialog1.getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);

        progress_bar = findViewById(R.id.progress_bar);

//        FrameLayout adMobView = (FrameLayout) findViewById(R.id.adMobView);
//        Common.NativeBanner(this, adMobView, "item_native");

        WindowManager.LayoutParams layoutParams1 = new WindowManager.LayoutParams();
        Window window = dialog1.getWindow();
        layoutParams1.copyFrom(window.getAttributes());
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int height = displayMetrics.heightPixels;
        int width = displayMetrics.widthPixels;

        layoutParams1.width = width;
        layoutParams1.height = height;
        window.setAttributes(layoutParams1);

        pos = getIntent().getIntExtra("position", 0);
        ImageView ivBack = (ImageView) findViewById(R.id.ivBack);
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        txtName = (TextView) findViewById(R.id.txtName);
        bindView();
    }

    @Override
    public void onBackPressed() {
        setResult(RESULT_OK);
        finish();
    }

    private void bindView() {
        webView = (WebView) findViewById(R.id.webView);
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);// enable javascript
        webSettings.setJavaScriptCanOpenWindowsAutomatically(true);

        webView.setInitialScale(1);
        webView.getSettings().setLoadWithOverviewMode(true);
        webView.getSettings().setUseWideViewPort(true);
        webView.setScrollBarStyle(WebView.SCROLLBARS_OUTSIDE_OVERLAY);
        webView.setScrollbarFadingEnabled(true);
        webView.getSettings().setBuiltInZoomControls(true);
        webView.getSettings().setDisplayZoomControls(false);

        webView.setWebViewClient(new WebViewClient() {

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {

                if (progress_bar.getVisibility() == View.GONE) {
                    progress_bar.setVisibility(View.VISIBLE);
                }

                if (url.startsWith("http:") || url.startsWith("https:")) {
                    return false;
                }
                // Otherwise allow the OS to handle things like tel, mailto, etc.
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(intent);
                return true;
            }

            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                Toast.makeText(WebSearchActivity.this, description, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (progress_bar.getVisibility() == View.VISIBLE) {
                    progress_bar.setVisibility(View.GONE);
                }
            }
        });
        if (Common.CheckNet(WebSearchActivity.this)) {
            if (pos == 0) {
                txtName.setText("Activate UAN");
                webView.loadUrl("https://unifiedportal-mem.epfindia.gov.in/memberinterface");
            } else if (pos == 1) {
                txtName.setText("Balance(Online)");
                webView.loadUrl("https://passbook.epfindia.gov.in/MemberPassBook/Login.jsp");
            } else if (pos == 2) {
                txtName.setText("Pensioners");
                webView.loadUrl("https://mis.epfindia.gov.in/PensionPaymentEnquiry/");
            } else if (pos == 3) {
                txtName.setText("TRRN status");
                webView.loadUrl("https://unifiedportal-epfo.epfindia.gov.in/publicPortal/no-auth/misReport/home/loadSearchTrrnHome");
            } else if (pos == 8) {
                txtName.setText("FAQs");
                webView.loadUrl("https://www.epfindia.gov.in/site_en/faq.php");
            } else if (pos == 9) {
                txtName.setText("News");
                webView.loadUrl("https://news.google.com/news/search/section/q/employee%20provident%20fund/employee%20provident%20fund?hl=en&gl=US&ned=us");
            } else if (pos == 12) {
                txtName.setText("Locate Office");
                webView.loadUrl("https://search.epfindia.gov.in/locate_office/office_location.php");
            }
        } else {
            if (pos == 0) {
                txtName.setText("Activate UAN");
                webView.loadUrl("https://passbook.epfindia.gov.in/MemberPassBook/Login.jsp");
            } else if (pos == 1) {
                txtName.setText("Balance(Online)");
                webView.loadUrl("https://passbook.epfindia.gov.in/MemberPassBook/Login.jsp");
            } else if (pos == 2) {
                txtName.setText("Pensioners");
                webView.loadUrl("https://mis.epfindia.gov.in/PensionPaymentEnquiry/");
            } else if (pos == 3) {
                txtName.setText("TRRN status");
                webView.loadUrl("https://unifiedportal-epfo.epfindia.gov.in/publicPortal/no-auth/misReport/home/loadSearchTrrnHome");
            } else if (pos == 7) {
                txtName.setText("FAQs");
                webView.loadUrl("https://www.epfindia.gov.in/site_en/faq.php");
            } else if (pos == 8) {
                txtName.setText("News");
                webView.loadUrl("https://news.google.com/news/search/section/q/employee%20provident%20fund/employee%20provident%20fund?hl=en&gl=US&ned=us");
            } else if (pos == 11) {
                txtName.setText("Locate Office");
                webView.loadUrl("https://search.epfindia.gov.in/locate_office/office_location.php");
            }
        }


    }

}
