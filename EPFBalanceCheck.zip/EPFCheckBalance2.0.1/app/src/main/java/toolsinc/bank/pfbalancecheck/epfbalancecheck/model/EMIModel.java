package toolsinc.bank.pfbalancecheck.epfbalancecheck.model;

import java.io.Serializable;

public class EMIModel implements Serializable {
    private double emi;
    private long firstEMIDate;
    private Double loanTenure;
    private String loanType;
    private Double principalAmount;
    private double processFeeAmount;
    private double processFeePercentage;
    private String profileName;
    private double roiPercentage;
    private long rowIndex;
    private double totalInterestAmount;
    private double totalPaymentAmount;

    public long getRowIndex() {
        return this.rowIndex;
    }

    public void setRowIndex(long j) {
        this.rowIndex = j;
    }

    public Double getPrincipalAmount() {
        return this.principalAmount;
    }

    public void setPrincipalAmount(Double d) {
        this.principalAmount = d;
    }

    public Double getLoanTenure() {
        return this.loanTenure;
    }

    public void setLoanTenure(Double d) {
        this.loanTenure = d;
    }

    public double getRoiPercentage() {
        return this.roiPercentage;
    }

    public void setRoiPercentage(double d) {
        this.roiPercentage = d;
    }

    public double getProcessFeePercentage() {
        return this.processFeePercentage;
    }

    public void setProcessFeePercentage(double d) {
        this.processFeePercentage = d;
    }

    public double getEmi() {
        return this.emi;
    }

    public void setEmi(double d) {
        this.emi = d;
    }

    public double getTotalInterestAmount() {
        return this.totalInterestAmount;
    }

    public void setTotalInterestAmount(double d) {
        this.totalInterestAmount = d;
    }

    public double getProcessFeeAmount() {
        return this.processFeeAmount;
    }

    public void setProcessFeeAmount(double d) {
        this.processFeeAmount = d;
    }

    public double getTotalPaymentAmount() {
        return this.totalPaymentAmount;
    }

    public void setTotalPaymentAmount(double d) {
        this.totalPaymentAmount = d;
    }

    public String getProfileName() {
        return this.profileName;
    }

    public void setProfileName(String str) {
        this.profileName = str;
    }

    public long getFirstEMIDate() {
        return this.firstEMIDate;
    }

    public void setFirstEMIDate(long j) {
        this.firstEMIDate = j;
    }

    public String getLoanType() {
        return this.loanType;
    }

    public void setLoanType(String str) {
        this.loanType = str;
    }
}
