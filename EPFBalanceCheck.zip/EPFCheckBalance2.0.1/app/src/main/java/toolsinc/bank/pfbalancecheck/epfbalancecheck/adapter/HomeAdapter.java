package toolsinc.bank.pfbalancecheck.epfbalancecheck.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.u.securekeys.SecureEnvironment;

import toolsinc.bank.pfbalancecheck.epfbalancecheck.R;
import toolsinc.bank.pfbalancecheck.epfbalancecheck.splashexit.Utils.Common;

public class HomeAdapter extends BaseAdapter {

    Context context;
    private int[] itemImage;
    private String[] itemName;
    private static LayoutInflater inflater = null;

    public HomeAdapter(Context context, int[] itemImage, String[] itemName) {
        this.context = context;
        this.itemImage = itemImage;
        this.itemName = itemName;
        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return itemImage.length;
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View rowView = convertView;
        ViewHolder viewHolder;
        if (itemImage[position] != 0) {
            if (rowView == null) {
                rowView = inflater.inflate(R.layout.item_home, parent, false);
                viewHolder = new ViewHolder();

                viewHolder.imgMain = (ImageView) rowView.findViewById(R.id.imgMain);
                viewHolder.txtName = (TextView) rowView.findViewById(R.id.txtName);

                rowView.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder) convertView.getTag();
            }

            viewHolder.imgMain.setImageResource(itemImage[position]);
            viewHolder.txtName.setText(itemName[position]);
        } else {
            if (rowView == null) {
                rowView = inflater.inflate(R.layout.item_home1, parent, false);
                viewHolder = new ViewHolder();

                FrameLayout adMobView = (FrameLayout) rowView.findViewById(R.id.adMobView);
                Common.NativeGrid(context, adMobView, "main_grid_native");

                rowView.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder) convertView.getTag();
            }
        }
//        System.gc();
        return rowView;
    }

    public class ViewHolder {
        ImageView imgMain;
        TextView txtName;

    }


}
