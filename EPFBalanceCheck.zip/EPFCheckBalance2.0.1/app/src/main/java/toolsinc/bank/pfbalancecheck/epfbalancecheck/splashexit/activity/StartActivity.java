package toolsinc.bank.pfbalancecheck.epfbalancecheck.splashexit.activity;

import android.annotation.TargetApi;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.AppCompatActivity;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.u.securekeys.SecureEnvironment;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import toolsinc.bank.pfbalancecheck.epfbalancecheck.BuildConfig;
import toolsinc.bank.pfbalancecheck.epfbalancecheck.R;
import toolsinc.bank.pfbalancecheck.epfbalancecheck.activity.MainActivity;
import toolsinc.bank.pfbalancecheck.epfbalancecheck.splashexit.Utils.Common;


public class StartActivity extends AppCompatActivity implements View.OnClickListener {

    private FrameLayout nativeAdContainer;
    private ImageView ivPrivacyPolicy, ivStart, ivMyCreation, ivShare, ivRate, ivMoreApps;
    private static final int REQ_CODE_PERMISSION = 111;
    private InterstitialAd mInterstitialAdMob;
    private Dialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_first);

        initAdmobFullAd(this);
        loadAdmobAd();

        if (Common.getPrefint(this, "Adcount1") == -1) {
            Common.setPrefint(this, "Adcount1", new Random().nextInt(3) - 1);
        }

        if (Build.VERSION.SDK_INT >= 23) {
            checkMultiplePermissions();
        }

        init();

        if (!Common.getPrefBoolean(StartActivity.this, "isToken")) {
            RegisterToken1();
        }

        exitDialog();

    }

    private void exitDialog() {
        dialog = new Dialog(this, android.R.style.Theme_Translucent_NoTitleBar_Fullscreen);
        dialog.setContentView(R.layout.dialog_exit);
        dialog.getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);

        dialog.setOnKeyListener(new DialogInterface.OnKeyListener() {
            @Override
            public boolean onKey(DialogInterface dialogInterface, int keyCode, KeyEvent keyEvent) {
                if (keyCode == KeyEvent.KEYCODE_BACK && keyEvent.getAction() == KeyEvent.ACTION_UP) {
                    return false;
                }
                return true;
            }
        });

        FrameLayout native_ad_container = (FrameLayout) dialog.findViewById(R.id.native_ad_container);
        TextView send_feedback = (TextView) dialog.findViewById(R.id.send_feedback);
        send_feedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri uri1 = Uri.parse("https://play.google.com/store/apps/details?id=" + getPackageName());
                Intent inrate = new Intent(Intent.ACTION_VIEW, uri1);
                try {
                    startActivity(inrate);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(StartActivity.this, "You don't have Google Play installed", Toast.LENGTH_LONG).show();
                }
            }
        });

        TextView tv_yes = (TextView) dialog.findViewById(R.id.tv_yes);
        tv_yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                finish();
            }
        });

        TextView tv_no = (TextView) dialog.findViewById(R.id.tv_no);
        tv_no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        Common.showGOOGLEAdvancesplash1(this, native_ad_container);
    }

    private void RegisterToken1() {
        String url;
        try {
            url = SecureEnvironment.getString("apicount") + "/" + SecureEnvironment.getString("aid") + "/" + getPackageName();
            JsonObjectRequest stringRequest = new JsonObjectRequest(Request.Method.GET, url, new JSONObject(),
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject jsonObject) {
                            try {
                                if (jsonObject != null) {
                                    if (jsonObject.getBoolean(SecureEnvironment.getString("response"))) {
                                        Common.setPrefBoolean(StartActivity.this, "isToken", true);
                                    }
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                        }
                    });
            RequestQueue requestQueue = Volley.newRequestQueue(this);
            requestQueue.add(stringRequest);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
        }
    }

    private void checkMultiplePermissions() {
        if (Build.VERSION.SDK_INT >= 23) {
            List<String> permissionsNeeded = new ArrayList();
            List<String> permissionsList = new ArrayList();
            if (!addPermission(permissionsList, "android.permission.WRITE_EXTERNAL_STORAGE")) {
                permissionsNeeded.add("Write Storage");
            }
            if (!addPermission(permissionsList, "android.permission.READ_EXTERNAL_STORAGE")) {
                permissionsNeeded.add("Read Storage");
            }
            if (permissionsList.size() > 0) {
                requestPermissions((String[]) permissionsList.toArray(new String[permissionsList.size()]), REQ_CODE_PERMISSION);
                return;
            }
        }
    }

    private boolean addPermission(List<String> permissionsList, String permission) {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) {
            permissionsList.add(permission);
            if (!shouldShowRequestPermissionRationale(permission)) {
                return false;
            }
        }
        return true;
    }

    @TargetApi(Build.VERSION_CODES.M)
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case REQ_CODE_PERMISSION:
                Map<String, Integer> perms = new HashMap();
                perms.put("android.permission.WRITE_EXTERNAL_STORAGE", Integer.valueOf(0));
                perms.put("android.permission.READ_EXTERNAL_STORAGE", Integer.valueOf(0));
                for (int i = 0; i < permissions.length; i++) {
                    perms.put(permissions[i], Integer.valueOf(grantResults[i]));
                }

                if (((Integer) perms.get("android.permission.READ_EXTERNAL_STORAGE")).intValue() == 0 && ((Integer) perms.get("android.permission.WRITE_EXTERNAL_STORAGE")).intValue() == 0) {
                    break;
                } else if (Build.VERSION.SDK_INT >= 23) {
                    Toast.makeText(getApplicationContext(), "My App cannot run without Storage Permissions.\nRelaunch My App or allow permissions in Applications Settings", Toast.LENGTH_LONG).show();
                    finish();
                    break;
                } else {
                    break;
                }

            default:
                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
                return;
        }
    }

    private void init() {

        nativeAdContainer = (FrameLayout) findViewById(R.id.nativeAdContainer);
        Common.showGOOGLEAdvancesplash1(this, nativeAdContainer);

        ivStart = findViewById(R.id.ivStart);
        ivStart.setOnClickListener(this);
        ivRate = findViewById(R.id.ivRate);
        ivRate.setOnClickListener(this);
        ivMyCreation = findViewById(R.id.ivMyCreation);
        ivMyCreation.setOnClickListener(this);
        ivShare = findViewById(R.id.ivShare);
        ivShare.setOnClickListener(this);
        ivPrivacyPolicy = findViewById(R.id.ivPrivacyPolicy);
        ivPrivacyPolicy.setOnClickListener(this);
        ivMoreApps = findViewById(R.id.ivMoreApps);
        ivMoreApps.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {

            case R.id.ivStart:
                startActivity(new Intent(this, MainActivity.class));
                showAdmobInterstitial();
                break;

            case R.id.ivRate:
                Rateus();
                break;

            case R.id.ivPrivacyPolicy:
                PrivacyPolicy();
                break;

            case R.id.ivShare:
                share();
                break;

            case R.id.ivMoreApps:
                moreapp();
                break;

            case R.id.ivMyCreation:
                break;

        }
    }

    public void PrivacyPolicy() {
        startActivity(new Intent(StartActivity.this, PrivacyPolicyActivity.class));
    }

    public void Rateus() {
        Uri uri1 = Uri.parse("https://play.google.com/store/apps/details?id=" + getPackageName());
        Intent myAppLinkToMarket = new Intent(Intent.ACTION_VIEW, uri1);
        try {
            startActivity(myAppLinkToMarket);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(StartActivity.this, "You don't have Google Play installed", Toast.LENGTH_LONG).show();
        }
    }

    private void moreapp() {
        if (Common.CheckNet(this)) {
            try {
                Uri uri = Uri.parse("https://play.google.com/store/apps/developer?id=Vinions");
                Intent myAppLinkToMarket = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(myAppLinkToMarket);
            } catch (Exception e) {
                Toast.makeText(StartActivity.this, "You don't have Google Play installed", Toast.LENGTH_LONG).show();
            }
        } else {
            Toast.makeText(this, "No Internet Connection..", Toast.LENGTH_SHORT).show();
        }
    }

    private void share() {
        Bitmap bm = BitmapFactory.decodeResource(getResources(), R.mipmap.ic_launcher);
        File f = new File(getExternalCacheDir() + "/image.png");
        try {
            FileOutputStream outStream = new FileOutputStream(f);
            bm.compress(Bitmap.CompressFormat.PNG, 100, outStream);
            outStream.flush();
            outStream.close();
        } catch (Exception e) {
            e.printStackTrace();
            return;
        }
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("image/*");
        shareIntent.putExtra(Intent.EXTRA_TEXT, "https://play.google.com/store/apps/details?id=" + getPackageName());
        Uri urishare;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
            urishare = FileProvider.getUriForFile(StartActivity.this, BuildConfig.APPLICATION_ID + ".provider", f);
        else {
            urishare = Uri.fromFile(f);
        }
        shareIntent.putExtra(Intent.EXTRA_STREAM, urishare);
        startActivity(Intent.createChooser(shareIntent, "Share Image using"));
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && requestCode == 1010) {
            finish();
        }
    }

    @Override
    public void onBackPressed() {
        dialog.show();
    }

    //Ad Start
    private void initAdmobFullAd(Context context) {
        mInterstitialAdMob = new InterstitialAd(context);
        mInterstitialAdMob.setAdUnitId(SecureEnvironment.getString("sp_start_inter"));
        mInterstitialAdMob.setAdListener(new com.google.android.gms.ads.AdListener() {
            @Override
            public void onAdClosed() {
                loadAdmobAd();
            }

            @Override
            public void onAdLoaded() {

            }

            @Override
            public void onAdOpened() {
                //   super.onAdOpened();
            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);
            }
        });

    }

    private void loadAdmobAd() {
        if (mInterstitialAdMob != null && !mInterstitialAdMob.isLoaded()) {
            mInterstitialAdMob.loadAd(new AdRequest.Builder().build());
        }
    }

    private void showAdmobInterstitial() {
        if (mInterstitialAdMob != null && mInterstitialAdMob.isLoaded()) {
            mInterstitialAdMob.show();
        }
    }
    //Ad End


}
