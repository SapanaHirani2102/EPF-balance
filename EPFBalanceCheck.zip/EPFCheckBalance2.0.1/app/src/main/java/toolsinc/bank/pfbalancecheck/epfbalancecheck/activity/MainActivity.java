package toolsinc.bank.pfbalancecheck.epfbalancecheck.activity;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.u.securekeys.SecureEnvironment;

import java.util.Random;

import toolsinc.bank.pfbalancecheck.epfbalancecheck.R;
import toolsinc.bank.pfbalancecheck.epfbalancecheck.adapter.HomeAdapter;
import toolsinc.bank.pfbalancecheck.epfbalancecheck.splashexit.Utils.Common;

public class MainActivity extends AppCompatActivity {

    private GridView gridView;

    public static int[] itemImage = {R.drawable.image_01, R.drawable.image_02, R.drawable.image_03, R.drawable.image_04, R.drawable.image_05,
            R.drawable.image_06, R.drawable.image_07, R.drawable.image_08, R.drawable.image_09, R.drawable.image_10, R.drawable.image_11,
            R.drawable.image_12};

    public static String[] itemName = {"Activate UAN", "Balance(Online)", "Pensioners", "TRRN Status", "Claim",
            "Balance(Call)", "Balance(SMS)", "FAQs", "News", "Helpline(Tollfree)",
            "EPF Online", "Locate Office"};

    public static int[] itemImage1 = {R.drawable.image_01, R.drawable.image_02, R.drawable.image_03, R.drawable.image_04, R.drawable.image_05,
            R.drawable.image_06, R.drawable.image_07, 0, R.drawable.image_08, R.drawable.image_09, R.drawable.image_10, R.drawable.image_11,
            R.drawable.image_12};

    public static String[] itemName1 = {"Activate UAN", "Balance(Online)", "Pensioners", "TRRN Status", "Claim",
            "Balance(Call)", "Balance(SMS)", null, "FAQs", "News", "Helpline(Tollfree)",
            "EPF Online", "Locate Office"};

    private InterstitialAd mInterstitialAdMob;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initAdmobFullAd(this);
        loadAdmobAd();

        ImageView ivBack = (ImageView) findViewById(R.id.ivBack);
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        FrameLayout adMobView = (FrameLayout) findViewById(R.id.adMobView);
        Common.NativeBanner(this, adMobView, "main_native1");

        bindView();

        if (Common.getPrefint(this, "Adcount") == -1) {
            Common.setPrefint(this, "Adcount", new Random().nextInt(3) - 1);
        }

        LinearLayout sipCalculator = findViewById(R.id.sipCalculator);
        sipCalculator.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, CalculatorActivity.class);
                startActivity(i);
//                showAdmobInterstitial();
            }
        });
    }

    private void bindView() {
        gridView = findViewById(R.id.gridView);

        if (Common.CheckNet(this)) {
            gridView.setAdapter(new HomeAdapter(MainActivity.this, itemImage1, itemName1));
        } else {
            gridView.setAdapter(new HomeAdapter(MainActivity.this, itemImage, itemName));
        }
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent;
                if (Common.CheckNet(MainActivity.this)) {
                    if (position == 7) {
                    } else if (position == 4) {
                        startActivity(new Intent(MainActivity.this, ActivityClaim.class));
                        showAdmobInterstitial();
                    } else if (position == 5) {
                        intent = new Intent("android.intent.action.DIAL");
                        intent.setData(Uri.parse("tel:01122901406"));
                        startActivity(intent);
                    } else if (position == 6) {
                        intent = new Intent("android.intent.action.VIEW", Uri.parse("sms:7738299899"));
                        intent.putExtra("sms_body", "EPFOHO UAN ENG");
                        startActivity(intent);
                    } else if (position == 10) {
                        intent = new Intent("android.intent.action.DIAL");
                        intent.setData(Uri.parse("tel:1800118005"));
                        startActivity(intent);
                    } else if (position == 11) {
                        startActivity(new Intent(MainActivity.this, ActivityOnline.class));
                        showAdmobInterstitial();
                    } else {
                        intent = new Intent(MainActivity.this, WebSearchActivity.class);
                        intent.putExtra("position", position);
                        startActivityForResult(intent,100);
                    }
                } else {
                    if (position == 4) {
                        startActivity(new Intent(MainActivity.this, ActivityClaim.class));
                        showAdmobInterstitial();
                    } else if (position == 5) {
                        intent = new Intent("android.intent.action.DIAL");
                        intent.setData(Uri.parse("tel:01122901406"));
                        startActivity(intent);
                    } else if (position == 6) {
                        intent = new Intent("android.intent.action.VIEW", Uri.parse("sms:7738299899"));
                        intent.putExtra("sms_body", "EPFOHO UAN ENG");
                        startActivity(intent);
                    } else if (position == 9) {
                        intent = new Intent("android.intent.action.DIAL");
                        intent.setData(Uri.parse("tel:1800118005"));
                        startActivity(intent);
                    } else if (position == 10) {
                        startActivity(new Intent(MainActivity.this, ActivityOnline.class));
                        showAdmobInterstitial();
                    } else {
                        intent = new Intent(MainActivity.this, WebSearchActivity.class);
                        intent.putExtra("position", position);
                        startActivityForResult(intent,100);
                    }
                }
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && requestCode == 100) {
            showAdmobInterstitial();
        }

    }

    //Ad Start
    private void initAdmobFullAd(Context context) {
        mInterstitialAdMob = new InterstitialAd(context);
        mInterstitialAdMob.setAdUnitId(SecureEnvironment.getString("main_item_click"));
        mInterstitialAdMob.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                loadAdmobAd();
            }

            @Override
            public void onAdLoaded() {

            }

            @Override
            public void onAdOpened() {
                //   super.onAdOpened();
            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);
            }
        });

    }

    private void loadAdmobAd() {
        if (mInterstitialAdMob != null && !mInterstitialAdMob.isLoaded()) {
            mInterstitialAdMob.loadAd(new AdRequest.Builder().build());
        }
    }

    private void showAdmobInterstitial() {
        if (mInterstitialAdMob != null && mInterstitialAdMob.isLoaded()) {
            mInterstitialAdMob.show();
        }
    }
    //Ad End


}
