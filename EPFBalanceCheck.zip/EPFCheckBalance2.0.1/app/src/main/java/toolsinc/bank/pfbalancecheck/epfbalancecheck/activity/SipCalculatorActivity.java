package toolsinc.bank.pfbalancecheck.epfbalancecheck.activity;

import android.os.Bundle;
import android.os.Handler;
import androidx.appcompat.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.view.View.OnTouchListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.ads.InterstitialAd;

import java.text.NumberFormat;
import java.util.Locale;

import toolsinc.bank.pfbalancecheck.epfbalancecheck.R;
import toolsinc.bank.pfbalancecheck.epfbalancecheck.splashexit.Utils.Common;

public class SipCalculatorActivity extends AppCompatActivity {
    Button btn_investment_dec;
    Button btn_investment_inc;
    Button btn_period_dec;
    Button btn_period_inc;
    Button btn_return_dec;
    Button btn_return_inc;
    EditText interestrate;
    public double j;
    public double k;
    public double l = 500.0d;
    TextView label_investment;
    public double m = 0.5d;
    public double n = 0.5d;
    EditText noofyears;
    public TextView o;
    ImageView poweroff;
    ImageView reset;
    private Handler s = new Handler();
    EditText sippermonth;
    private boolean t = false;
    TextView totalwealth;
    TextView txt_investment;
    TextView txt_wealth;
    private boolean u = false;
    private final long v = 50;
    private final int w = 0;
    private final int x = 999999999;
    TextView sip, lumpsum;
    boolean isSip = true;
    private InterstitialAd mInterstitialAdMob;

    /* Access modifiers changed, original: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.sip_calculator);
//        getSupportActionBar().hide();

        FrameLayout adMobView = findViewById(R.id.bannerAd);
        Common.NativeBanner(this, adMobView, "item_native");

        interestrate = (EditText) findViewById(R.id.edit_interest);
        noofyears = (EditText) findViewById(R.id.edit_noofyears);
        sippermonth = (EditText) findViewById(R.id.edit_sippermonth);
        totalwealth = (TextView) findViewById(R.id.txt_total);
        txt_investment = (TextView) findViewById(R.id.txt_investment);
        txt_wealth = (TextView) findViewById(R.id.txt_wealth);
        label_investment = (TextView) findViewById(R.id.label_investment);
        btn_investment_dec = (Button) findViewById(R.id.btn_investment_dec);
        btn_investment_inc = (Button) findViewById(R.id.btn_investment_inc);
        btn_period_dec = (Button) findViewById(R.id.btn_period_dec);
        btn_period_inc = (Button) findViewById(R.id.btn_period_inc);
        btn_return_dec = (Button) findViewById(R.id.btn_return_dec);
        btn_return_inc = (Button) findViewById(R.id.btn_return_inc);
        poweroff = (ImageView) findViewById(R.id.poweroff);
        reset = (ImageView) findViewById(R.id.reset);

        sip = findViewById(R.id.sip);
        lumpsum = findViewById(R.id.lumpsum);

        sip.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                sip.setBackground(getResources().getDrawable(R.drawable.selected_state));
                lumpsum.setBackground(getResources().getDrawable(R.drawable.unselected_state));
                isSip = true;
                SipCalculatorActivity.this.label_investment.setText(" Monthly Investment");
                SipCalculatorActivity.this.o();
            }
        });

        lumpsum.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                sip.setBackground(getResources().getDrawable(R.drawable.unselected_state));
                lumpsum.setBackground(getResources().getDrawable(R.drawable.selected_state));
                isSip = false;
                SipCalculatorActivity.this.n();
                SipCalculatorActivity.this.label_investment.setText(" Investment Amount");
            }
        });

        o();
        a(this.btn_investment_dec, this.btn_investment_inc, this.l, this.sippermonth);
        a(this.btn_period_dec, this.btn_period_inc, this.n, this.noofyears);
        a(this.btn_return_dec, this.btn_return_inc, this.m, this.interestrate);
        this.poweroff.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                onBackPressed();
            }
        });
        this.reset.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                SipCalculatorActivity.this.k();
            }
        });
        this.interestrate.addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(Editable editable) {
                if (editable.toString().isEmpty()) {
                    SipCalculatorActivity.this.interestrate.setText("1");
                }
                if (isSip) {
                    SipCalculatorActivity.this.o();
                } else {
                    SipCalculatorActivity.this.n();
                }
            }

            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }
        });
        this.noofyears.addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(Editable editable) {
                if (editable.toString().isEmpty()) {
                    SipCalculatorActivity.this.noofyears.setText("1");
                }
                if (isSip) {
                    SipCalculatorActivity.this.o();
                } else {
                    SipCalculatorActivity.this.n();
                }
            }

            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }
        });
        this.sippermonth.addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(Editable editable) {
                if (editable.toString().isEmpty()) {
                    SipCalculatorActivity.this.sippermonth.setText("0");
                }
                if (isSip) {
                    SipCalculatorActivity.this.o();
                } else {
                    SipCalculatorActivity.this.n();
                }
            }

            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }
        });
    }

    class a implements Runnable {
        a() {
        }

        public void a(TextView textView, double d) {
            SipCalculatorActivity.this.o = textView;
            SipCalculatorActivity.this.k = d;
        }

        public void run() {
            Handler d;
            Runnable aVar;
            if (SipCalculatorActivity.this.t) {
                SipCalculatorActivity.this.l();
                d = SipCalculatorActivity.this.s;
                aVar = new a();
            } else if (SipCalculatorActivity.this.u) {
                SipCalculatorActivity.this.m();
                d = SipCalculatorActivity.this.s;
                aVar = new a();
            } else {
                return;
            }
            d.postDelayed(aVar, 50);
        }
    }

    private double a(double d, double d2, double d3) {
        d = (d / 100.0d) / 12.0d;
        double d4 = 1.0d + d;
        return d3 * (((Math.pow(d4, 12.0d * d2) - 1.0d) / d) * d4);
    }

    private void a(Button button, Button button2, final double d, final TextView textView) {
        button.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                SipCalculatorActivity.this.k = d;
                SipCalculatorActivity.this.o = textView;
                SipCalculatorActivity.this.m();
                if (isSip) {
                    SipCalculatorActivity.this.o();
                } else {
                    SipCalculatorActivity.this.n();
                }
            }
        });
        button2.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                SipCalculatorActivity.this.k = d;
                SipCalculatorActivity.this.o = textView;
                SipCalculatorActivity.this.l();
                if (isSip) {
                    SipCalculatorActivity.this.o();
                } else {
                    SipCalculatorActivity.this.n();
                }
            }
        });
        button.setOnLongClickListener(new OnLongClickListener() {
            public boolean onLongClick(View view) {
                SipCalculatorActivity.this.u = true;
                a aVar = new a();
                aVar.a(textView, d);
                SipCalculatorActivity.this.s.post(aVar);
                return false;
            }
        });
        button2.setOnLongClickListener(new OnLongClickListener() {
            public boolean onLongClick(View view) {
                SipCalculatorActivity.this.t = true;
                a aVar = new a();
                aVar.a(textView, d);
                SipCalculatorActivity.this.s.post(aVar);
                return false;
            }
        });
        button2.setOnTouchListener(new OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (motionEvent.getAction() == 1 && SipCalculatorActivity.this.t) {
                    SipCalculatorActivity.this.t = false;
                    if (isSip) {
                        SipCalculatorActivity.this.o();
                        return false;
                    }
                    SipCalculatorActivity.this.n();
                }
                return false;
            }
        });
        button.setOnTouchListener(new OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (motionEvent.getAction() == 1 && SipCalculatorActivity.this.u) {
                    SipCalculatorActivity.this.u = false;
                    if (isSip) {
                        SipCalculatorActivity.this.o();
                        return false;
                    }
                    SipCalculatorActivity.this.n();
                }
                return false;
            }
        });
    }

    private void n() {
        double parseDouble = Double.parseDouble(this.interestrate.getText().toString());
        double parseDouble2 = Double.parseDouble(this.noofyears.getText().toString());
        double parseDouble3 = Double.parseDouble(this.sippermonth.getText().toString());
        parseDouble = Math.pow(1.0d + (parseDouble / 100.0d), parseDouble2) * parseDouble3;
        Locale locale = new Locale("en", "IN");
        String string = getResources().getString(R.string.Rs);
        TextView textView = this.totalwealth;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(string);
        stringBuilder.append(" ");
        stringBuilder.append(String.valueOf(NumberFormat.getNumberInstance(locale).format(Math.round(parseDouble))));
        textView.setText(stringBuilder.toString());
        parseDouble = (double) Math.abs(Math.round(parseDouble - parseDouble3));
        parseDouble3 = (double) Math.abs(Math.round(parseDouble3));
        textView = this.txt_wealth;
        stringBuilder = new StringBuilder();
        stringBuilder.append(string);
        stringBuilder.append(" ");
        stringBuilder.append(String.valueOf(NumberFormat.getNumberInstance(locale).format(parseDouble)));
        textView.setText(stringBuilder.toString());
        TextView textView2 = this.txt_investment;
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(string);
        stringBuilder2.append(" ");
        stringBuilder2.append(String.valueOf(NumberFormat.getNumberInstance(locale).format(parseDouble3)));
        textView2.setText(stringBuilder2.toString());
    }

    private void o() {
        double parseDouble = Double.parseDouble(this.interestrate.getText().toString());
        double parseDouble2 = Double.parseDouble(this.noofyears.getText().toString());
        double parseDouble3 = Double.parseDouble(this.sippermonth.getText().toString());
        double a = a(parseDouble, parseDouble2, parseDouble3);
        String string = getResources().getString(R.string.Rs);
        Log.d("Log", getResources().getConfiguration().locale.toString());
        Locale locale = new Locale("en", "IN");
        TextView textView = this.totalwealth;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(string);
        stringBuilder.append(" ");
        stringBuilder.append(String.valueOf(NumberFormat.getNumberInstance(locale).format(Math.round(a))));
        textView.setText(stringBuilder.toString());
        double abs = (double) Math.abs(Math.round(parseDouble3 * (parseDouble2 * 12.0d)));
        a = (double) Math.abs(Math.round(abs - a));
        TextView textView2 = this.txt_wealth;
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(string);
        stringBuilder2.append(" ");
        stringBuilder2.append(String.valueOf(NumberFormat.getNumberInstance(locale).format(a)));
        textView2.setText(stringBuilder2.toString());
        TextView textView3 = this.txt_investment;
        StringBuilder stringBuilder3 = new StringBuilder();
        stringBuilder3.append(string);
        stringBuilder3.append(" ");
        stringBuilder3.append(String.valueOf(NumberFormat.getNumberInstance(locale).format(abs)));
        textView3.setText(stringBuilder3.toString());
    }

    public void k() {
        isSip = true;
        sip.setBackground(getResources().getDrawable(R.drawable.selected_state));
        lumpsum.setBackground(getResources().getDrawable(R.drawable.unselected_state));
        this.noofyears.setText("15");
        this.sippermonth.setText("1000");
        this.interestrate.setText("12");
        o();
    }

    public void l() {
        this.j = Double.parseDouble(this.o.getText().toString());
        if (this.j < 9.99999999E8d) {
            this.j += this.k;
            this.o.setText(String.valueOf(this.j));
        }
    }

    public void m() {
        this.j = Double.parseDouble(this.o.getText().toString());
        if (this.j > 0.0d) {
            this.j -= this.k;
            this.o.setText(String.valueOf(this.j));
        }
    }
}
