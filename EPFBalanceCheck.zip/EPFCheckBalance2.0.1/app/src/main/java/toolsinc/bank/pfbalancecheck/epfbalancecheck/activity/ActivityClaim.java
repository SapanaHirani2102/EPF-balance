package toolsinc.bank.pfbalancecheck.epfbalancecheck.activity;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.u.securekeys.SecureEnvironment;

import toolsinc.bank.pfbalancecheck.epfbalancecheck.R;
import toolsinc.bank.pfbalancecheck.epfbalancecheck.splashexit.Utils.Common;

public class ActivityClaim extends Activity {
    private Button btn1;
    private Button btn2;
    private Button btn3;
    public static int poition;
    private Dialog dialog1;
    private InterstitialAd mInterstitialAdMob;
    private LinearLayout add;


    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_claim);
        LinearLayout add = (LinearLayout) findViewById(R.id.add);
        ImageView ivBack = (ImageView) findViewById(R.id.ivBack);
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        FrameLayout frm_ad = (FrameLayout) findViewById(R.id.adMobView);
        Common.NativeBanner1(this, frm_ad);

        initAdmobFullAd(this);
        loadAdmobAd();
//
//        dialog1 = new Dialog(ActivityClaim.this, R.style.DialogCustomTheme);
//        dialog1.setContentView(R.layout.dialog_ad);
//        dialog1.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
//        dialog1.getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
//
//
//        WindowManager.LayoutParams layoutParams1 = new WindowManager.LayoutParams();
//        Window window = dialog1.getWindow();
//        layoutParams1.copyFrom(window.getAttributes());
//        DisplayMetrics displayMetrics = new DisplayMetrics();
//        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
//        int height = displayMetrics.heightPixels;
//        int width = displayMetrics.widthPixels;
//
//        layoutParams1.width = width;
//        layoutParams1.height = height;
//        window.setAttributes(layoutParams1);

        if (Common.CheckNet(this)) {
            add.setVisibility(View.VISIBLE);
        } else {
            add.setVisibility(View.GONE);
        }

        btn1 = (Button) findViewById(R.id.btn1);
        btn2 = (Button) findViewById(R.id.btn2);
        btn3 = (Button) findViewById(R.id.btn3);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                poition = 0;
                startActivityForResult(new Intent(ActivityClaim.this, toolsinc.bank.pfbalancecheck.epfbalancecheck.activity.WebSearchActivity1.class),100);
            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                poition = 1;
                startActivityForResult(new Intent(ActivityClaim.this, toolsinc.bank.pfbalancecheck.epfbalancecheck.activity.WebSearchActivity1.class),100);
            }
        });

        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                poition = 2;
                startActivityForResult(new Intent(ActivityClaim.this, toolsinc.bank.pfbalancecheck.epfbalancecheck.activity.WebSearchActivity1.class),100);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && requestCode == 100) {
            showAdmobInterstitial();
        }

    }

    //Ad Start
    private void initAdmobFullAd(Context context) {
        mInterstitialAdMob = new InterstitialAd(context);
        mInterstitialAdMob.setAdUnitId(SecureEnvironment.getString("claim_list_click_inter"));
        mInterstitialAdMob.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                loadAdmobAd();
            }

            @Override
            public void onAdLoaded() {

            }

            @Override
            public void onAdOpened() {
                //   super.onAdOpened();
            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);
            }
        });

    }

    private void loadAdmobAd() {
        if (mInterstitialAdMob != null && !mInterstitialAdMob.isLoaded()) {
            mInterstitialAdMob.loadAd(new AdRequest.Builder().build());
        }
    }

    private void showAdmobInterstitial() {
        if (mInterstitialAdMob != null && mInterstitialAdMob.isLoaded()) {
            mInterstitialAdMob.show();
        }
    }
    //Ad End

}
