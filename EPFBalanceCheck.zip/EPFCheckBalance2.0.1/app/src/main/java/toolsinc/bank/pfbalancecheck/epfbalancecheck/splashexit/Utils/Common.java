package toolsinc.bank.pfbalancecheck.epfbalancecheck.splashexit.Utils;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.NativeContentAd;
import com.google.android.gms.ads.formats.NativeContentAdView;
import com.u.securekeys.SecureEnvironment;
import com.u.securekeys.annotation.SecureKey;
import com.u.securekeys.annotation.SecureKeys;

import java.util.List;

import toolsinc.bank.pfbalancecheck.epfbalancecheck.R;

@SecureKeys({
        @SecureKey(key = "response", value = "status"),
        @SecureKey(key = "appname", value = "Application_Name"),
        @SecureKey(key = "applink", value = "Application_Link"),
        @SecureKey(key = "icon", value = "Icon_Link"),
        @SecureKey(key = "banner", value = "Banner"),
        @SecureKey(key = "package", value = "Package_Name"),
        @SecureKey(key = "privacy", value = "Privacy_Link"),
        @SecureKey(key = "account", value = "account_link"),
        @SecureKey(key = "approve", value = "Is_Approve"),
        @SecureKey(key = "fb_banner", value = "Fb_Banner"),
        @SecureKey(key = "fb_inter", value = "Fb_Inter"),
        @SecureKey(key = "fb_native", value = "Fb_Native"),
        @SecureKey(key = "admob_inter", value = "Admob_Inter"),
        @SecureKey(key = "admob_native", value = "Admob_Native"),
        @SecureKey(key = "admob_banner", value = "Admob_Banner"),
        @SecureKey(key = "admob_video", value = "Admob_Video"),
        @SecureKey(key = "aid", value = "87"),
        @SecureKey(key = "sid", value = "8"),
        @SecureKey(key = "eid", value = "9"),
        @SecureKey(key = "DATA1", value = "splash_json"),
        @SecureKey(key = "DATA2", value = "exit_json"),
        @SecureKey(key = "dlink", value = "http://fostersol.com/Service/datalist"),
        @SecureKey(key = "apicount", value = "http://fostersol.com/Service/appCount"),

        @SecureKey(key = "admob_app_id", value = "ca-app-pub-3492867784457651~7001123511"),

        @SecureKey(key = "sp_start_inter", value = "ca-app-pub-3492867784457651/1118241440"),
        @SecureKey(key = "main_item_click", value = "ca-app-pub-3492867784457651/1118241440"),
        @SecureKey(key = "claim_list_click_inter", value = "ca-app-pub-3492867784457651/1118241440"),
        @SecureKey(key = "online_list_click_inter", value = "ca-app-pub-3492867784457651/1118241440"),

        @SecureKey(key = "item_native", value = "ca-app-pub-3492867784457651/6088016261"),
        @SecureKey(key = "sp_native", value = "ca-app-pub-3492867784457651/1140664110"),
        @SecureKey(key = "main_native1", value = "ca-app-pub-3492867784457651/3383684073"),
        @SecureKey(key = "main_grid_native", value = "ca-app-pub-3492867784457651/5435132347"),
        @SecureKey(key = "cliam_grid_native", value = "ca-app-pub-3492867784457651/1825337620"),
        @SecureKey(key = "online_grid_native", value = "ca-app-pub-3492867784457651/4860417276"),
        @SecureKey(key = "ex_native", value = "ca-app-pub-3492867784457651/5201653460")

})

public class Common {
    public static String privacyPolicy;
    public static String accountLink;
    public static boolean isApproved;

    public static final String DATA1 = "data1";
    public static final String DATA2 = "data2";

    public static Boolean CheckNet(Context context) {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    public static String getPrefString(Context context, String key) {
        if (context != null) {
            String PREF_NAME = context.getString(R.string.app_name);
            return context.getSharedPreferences(PREF_NAME, 0).getString(key, "");
        } else {
            return "";
        }
    }

    public static void setPrefString(Context context, String key, String value) {
        String PREF_NAME = context.getString(R.string.app_name);
        SharedPreferences.Editor editor = context.getSharedPreferences(PREF_NAME, 0).edit();
        editor.putString(key, value);
        editor.commit();
    }

    public static boolean getPrefBoolean(Context context, String key) {
        if (context != null) {
            String PREF_NAME = context.getString(R.string.app_name);
            return context.getSharedPreferences(PREF_NAME, 0).getBoolean(key, false);
        } else {
            return false;
        }
    }

    public static void setPrefBoolean(Context context, String key, boolean value) {
        String PREF_NAME = context.getString(R.string.app_name);
        SharedPreferences.Editor editor = context.getSharedPreferences(PREF_NAME, 0).edit();
        editor.putBoolean(key, value);
        editor.commit();
    }

    public static int getPrefint(Context context, String key) {
        if (context != null) {
            String PREF_NAME = context.getString(R.string.app_name);
            return context.getSharedPreferences(PREF_NAME, 0).getInt(key, -1);
        } else {
            return -1;
        }
    }

    public static void setPrefint(Context context, String key, int value) {
        String PREF_NAME = context.getString(R.string.app_name);
        SharedPreferences.Editor editor = context.getSharedPreferences(PREF_NAME, 0).edit();
        editor.putInt(key, value);
        editor.commit();
    }


    //sp act

    public static void SplashNative(final Context context, final FrameLayout frameLayout) {
        AdLoader.Builder builder = new AdLoader.Builder(context, SecureEnvironment.getString("sp_native"));
        builder.forContentAd(new NativeContentAd.OnContentAdLoadedListener() {
            public void onContentAdLoaded(NativeContentAd nativeContentAd) {
                NativeContentAdView nativeContentAdView = (NativeContentAdView) ((Activity) context).getLayoutInflater().inflate(R.layout.admob_native_ad, null);
                populateContentAdView(nativeContentAd, nativeContentAdView);
                frameLayout.removeAllViews();
                frameLayout.addView(nativeContentAdView);
            }
        });
        builder.withNativeAdOptions(new NativeAdOptions.Builder().setVideoOptions(new VideoOptions.Builder().setStartMuted(false).build()).build());
        builder.withAdListener(new AdListener() {
            public void onAdFailedToLoad(int i) {
                Log.e("rr1", "Failed to load native ad:: " + i);
            }
        }).build().loadAd(new AdRequest.Builder().build());
    }

    public static void populateContentAdView(NativeContentAd nativeContentAd, NativeContentAdView nativeContentAdView) {
        TextView contentad_headline = (TextView) nativeContentAdView.findViewById(R.id.contentad_headline);
        TextView contentad_call_to_action = (TextView) nativeContentAdView.findViewById(R.id.contentad_call_to_action);

        nativeContentAdView.setHeadlineView(nativeContentAdView.findViewById(R.id.contentad_headline));
//        nativeContentAdView.setImageView(nativeContentAdView.findViewById(R.id.contentad_image));
//        nativeContentAdView.setBodyView(nativeContentAdView.findViewById(R.id.contentad_body));
        nativeContentAdView.setCallToActionView(nativeContentAdView.findViewById(R.id.contentad_call_to_action));
        nativeContentAdView.setLogoView(nativeContentAdView.findViewById(R.id.contentad_logo));
//        nativeContentAdView.setAdvertiserView(nativeContentAdView.findViewById(R.id.contentad_advertiser));
        ((TextView) nativeContentAdView.getHeadlineView()).setText(nativeContentAd.getHeadline());
//        ((TextView) nativeContentAdView.getBodyView()).setText(nativeContentAd.getBody());
        ((TextView) nativeContentAdView.getCallToActionView()).setText(nativeContentAd.getCallToAction());
//        ((TextView) nativeContentAdView.getAdvertiserView()).setText(nativeContentAd.getAdvertiser());
//        List images = nativeContentAd.getImages();
//        if (images.size() > 0) {
//            ((ImageView) nativeContentAdView.getImageView()).setImageDrawable(((com.google.android.gms.ads.formats.NativeAd.Image) images.get(0)).getDrawable());
//        }
        com.google.android.gms.ads.formats.NativeAd.Image logo = nativeContentAd.getLogo();
        if (logo == null) {
            nativeContentAdView.getLogoView().setVisibility(View.INVISIBLE);
        } else {
            ((ImageView) nativeContentAdView.getLogoView()).setImageDrawable(logo.getDrawable());
            nativeContentAdView.getLogoView().setVisibility(View.VISIBLE);
        }
        nativeContentAdView.setNativeAd(nativeContentAd);
    }

    //end

    //main act
    public static void NativeBanner(final Context context, final FrameLayout frameLayout, String key) {
        AdLoader.Builder builder = new AdLoader.Builder(context, SecureEnvironment.getString(key));
        builder.forContentAd(new NativeContentAd.OnContentAdLoadedListener() {
            public void onContentAdLoaded(NativeContentAd nativeContentAd) {
                NativeContentAdView nativeContentAdView = (NativeContentAdView) ((Activity) context).getLayoutInflater().inflate(R.layout.admob_native_adbanner, null);
                populateContentAdView3(nativeContentAd, nativeContentAdView);
                frameLayout.removeAllViews();
                frameLayout.addView(nativeContentAdView);
            }
        });
        builder.withNativeAdOptions(new NativeAdOptions.Builder().setVideoOptions(new VideoOptions.Builder().setStartMuted(false).build()).build());
        builder.withAdListener(new AdListener() {
            public void onAdFailedToLoad(int i) {
                Log.e("sapana", "Failed to load native ad:: " + i);
            }
        }).build().loadAd(new AdRequest.Builder().build());
    }

    public static void populateContentAdView3(NativeContentAd nativeContentAd, NativeContentAdView nativeContentAdView) {
        TextView contentad_headline = (TextView) nativeContentAdView.findViewById(R.id.contentad_headline);
        TextView contentad_call_to_action = (TextView) nativeContentAdView.findViewById(R.id.contentad_call_to_action);

        nativeContentAdView.setHeadlineView(nativeContentAdView.findViewById(R.id.contentad_headline));
//        nativeContentAdView.setImageView(nativeContentAdView.findViewById(R.id.contentad_image));
//        nativeContentAdView.setBodyView(nativeContentAdView.findViewById(R.id.contentad_body));
        nativeContentAdView.setCallToActionView(nativeContentAdView.findViewById(R.id.contentad_call_to_action));
        nativeContentAdView.setLogoView(nativeContentAdView.findViewById(R.id.contentad_logo));
//        nativeContentAdView.setAdvertiserView(nativeContentAdView.findViewById(R.id.contentad_advertiser));
        ((TextView) nativeContentAdView.getHeadlineView()).setText(nativeContentAd.getHeadline());
//        ((TextView) nativeContentAdView.getBodyView()).setText(nativeContentAd.getBody());
        ((TextView) nativeContentAdView.getCallToActionView()).setText(nativeContentAd.getCallToAction());
//        ((TextView) nativeContentAdView.getAdvertiserView()).setText(nativeContentAd.getAdvertiser());
//        List images = nativeContentAd.getImages();
//        if (images.size() > 0) {
//            ((ImageView) nativeContentAdView.getImageView()).setImageDrawable(((com.google.android.gms.ads.formats.NativeAd.Image) images.get(0)).getDrawable());
//        }
        com.google.android.gms.ads.formats.NativeAd.Image logo = nativeContentAd.getLogo();
        if (logo == null) {
            nativeContentAdView.getLogoView().setVisibility(View.INVISIBLE);
        } else {
            ((ImageView) nativeContentAdView.getLogoView()).setImageDrawable(logo.getDrawable());
            nativeContentAdView.getLogoView().setVisibility(View.VISIBLE);
        }
        nativeContentAdView.setNativeAd(nativeContentAd);
    }
    //end

    //cliam
    public static void NativeBanner1(final Context context, final FrameLayout frameLayout) {
        AdLoader.Builder builder = new AdLoader.Builder(context, SecureEnvironment.getString("cliam_grid_native"));
        builder.forContentAd(new NativeContentAd.OnContentAdLoadedListener() {
            public void onContentAdLoaded(NativeContentAd nativeContentAd) {
                NativeContentAdView nativeContentAdView = (NativeContentAdView) ((Activity) context).getLayoutInflater().inflate(R.layout.ad_native, null);
                populateContentAdView31(nativeContentAd, nativeContentAdView);
                frameLayout.removeAllViews();
                frameLayout.addView(nativeContentAdView);
            }
        });
        builder.withNativeAdOptions(new NativeAdOptions.Builder().setVideoOptions(new VideoOptions.Builder().setStartMuted(false).build()).build());
        builder.withAdListener(new AdListener() {
            public void onAdFailedToLoad(int i) {
                Log.e("rr1", "Failed to load native ad:: " + i);
            }
        }).build().loadAd(new AdRequest.Builder().build());
    }

    public static void populateContentAdView31(NativeContentAd nativeContentAd, NativeContentAdView nativeContentAdView) {
        TextView contentad_headline = (TextView) nativeContentAdView.findViewById(R.id.contentad_headline);
        TextView contentad_call_to_action = (TextView) nativeContentAdView.findViewById(R.id.contentad_call_to_action);

        nativeContentAdView.setHeadlineView(nativeContentAdView.findViewById(R.id.contentad_headline));
//        nativeContentAdView.setImageView(nativeContentAdView.findViewById(R.id.contentad_image));
//        nativeContentAdView.setBodyView(nativeContentAdView.findViewById(R.id.contentad_body));
        nativeContentAdView.setCallToActionView(nativeContentAdView.findViewById(R.id.contentad_call_to_action));
        nativeContentAdView.setLogoView(nativeContentAdView.findViewById(R.id.contentad_logo));
//        nativeContentAdView.setAdvertiserView(nativeContentAdView.findViewById(R.id.contentad_advertiser));
        ((TextView) nativeContentAdView.getHeadlineView()).setText(nativeContentAd.getHeadline());
//        ((TextView) nativeContentAdView.getBodyView()).setText(nativeContentAd.getBody());
        ((TextView) nativeContentAdView.getCallToActionView()).setText(nativeContentAd.getCallToAction());
//        ((TextView) nativeContentAdView.getAdvertiserView()).setText(nativeContentAd.getAdvertiser());
//        List images = nativeContentAd.getImages();
//        if (images.size() > 0) {
//            ((ImageView) nativeContentAdView.getImageView()).setImageDrawable(((com.google.android.gms.ads.formats.NativeAd.Image) images.get(0)).getDrawable());
//        }
        com.google.android.gms.ads.formats.NativeAd.Image logo = nativeContentAd.getLogo();
        if (logo == null) {
            nativeContentAdView.getLogoView().setVisibility(View.INVISIBLE);
        } else {
            ((ImageView) nativeContentAdView.getLogoView()).setImageDrawable(logo.getDrawable());
            nativeContentAdView.getLogoView().setVisibility(View.VISIBLE);
        }
        nativeContentAdView.setNativeAd(nativeContentAd);
    }
    //end

    //main_grid

    public static void NativeGrid(final Context context, final FrameLayout frameLayout, String key) {
        AdLoader.Builder builder = new AdLoader.Builder(context, SecureEnvironment.getString(key));
        builder.forContentAd(new NativeContentAd.OnContentAdLoadedListener() {
            public void onContentAdLoaded(NativeContentAd nativeContentAd) {
                NativeContentAdView nativeContentAdView = (NativeContentAdView) ((Activity) context).getLayoutInflater().inflate(R.layout.grid_native, null);
                populateContentAdView2(nativeContentAd, nativeContentAdView);
                frameLayout.removeAllViews();
                frameLayout.addView(nativeContentAdView);
            }
        });
        builder.withNativeAdOptions(new NativeAdOptions.Builder().setVideoOptions(new VideoOptions.Builder().setStartMuted(false).build()).build());
        builder.withAdListener(new AdListener() {
            public void onAdFailedToLoad(int i) {
                Log.e("rr1", "Failed to load native ad:: " + i);
            }
        }).build().loadAd(new AdRequest.Builder().build());
    }

    public static void populateContentAdView2(NativeContentAd nativeContentAd, NativeContentAdView nativeContentAdView) {
        TextView contentad_headline = (TextView) nativeContentAdView.findViewById(R.id.contentad_headline);
        TextView contentad_call_to_action = (TextView) nativeContentAdView.findViewById(R.id.contentad_call_to_action);

        nativeContentAdView.setHeadlineView(nativeContentAdView.findViewById(R.id.contentad_headline));
//        nativeContentAdView.setImageView(nativeContentAdView.findViewById(R.id.contentad_image));
//        nativeContentAdView.setBodyView(nativeContentAdView.findViewById(R.id.contentad_body));
        nativeContentAdView.setCallToActionView(nativeContentAdView.findViewById(R.id.contentad_call_to_action));
        nativeContentAdView.setLogoView(nativeContentAdView.findViewById(R.id.contentad_logo));
//        nativeContentAdView.setAdvertiserView(nativeContentAdView.findViewById(R.id.contentad_advertiser));
        ((TextView) nativeContentAdView.getHeadlineView()).setText(nativeContentAd.getHeadline());
//        ((TextView) nativeContentAdView.getBodyView()).setText(nativeContentAd.getBody());
        ((TextView) nativeContentAdView.getCallToActionView()).setText(nativeContentAd.getCallToAction());
//        ((TextView) nativeContentAdView.getAdvertiserView()).setText(nativeContentAd.getAdvertiser());
//        List images = nativeContentAd.getImages();
//        if (images.size() > 0) {
//            ((ImageView) nativeContentAdView.getImageView()).setImageDrawable(((com.google.android.gms.ads.formats.NativeAd.Image) images.get(0)).getDrawable());
//        }
        com.google.android.gms.ads.formats.NativeAd.Image logo = nativeContentAd.getLogo();
        if (logo == null) {
            nativeContentAdView.getLogoView().setVisibility(View.INVISIBLE);
        } else {
            ((ImageView) nativeContentAdView.getLogoView()).setImageDrawable(logo.getDrawable());
            nativeContentAdView.getLogoView().setVisibility(View.VISIBLE);
        }
        nativeContentAdView.setNativeAd(nativeContentAd);
    }

    //end


    public static void showGOOGLEAdvancesplash1(final Context context, final FrameLayout frameLayout) {
        AdLoader.Builder builder = new AdLoader.Builder(context, SecureEnvironment.getString("sp_native"));
        builder.forContentAd(new NativeContentAd.OnContentAdLoadedListener() {
            public void onContentAdLoaded(NativeContentAd nativeContentAd) {
                NativeContentAdView nativeContentAdView = (NativeContentAdView) ((Activity) context).getLayoutInflater().inflate(R.layout.splash_admob_native, null);
                populateContentAdView1(nativeContentAd, nativeContentAdView);
                frameLayout.removeAllViews();
                frameLayout.addView(nativeContentAdView);
            }
        });
        builder.withNativeAdOptions(new NativeAdOptions.Builder().setVideoOptions(new VideoOptions.Builder().setStartMuted(false).build()).build());
        builder.withAdListener(new AdListener() {
            public void onAdFailedToLoad(int i) {
            }
        }).build().loadAd(new AdRequest.Builder().build());
    }

    public static void populateContentAdView1(NativeContentAd nativeContentAd, NativeContentAdView nativeContentAdView) {
        TextView contentad_headline = (TextView) nativeContentAdView.findViewById(R.id.contentad_headline);
        TextView sponsored_label = (TextView) nativeContentAdView.findViewById(R.id.sponsored_label);
        TextView contentad_body = (TextView) nativeContentAdView.findViewById(R.id.contentad_body);
        TextView contentad_advertiser = (TextView) nativeContentAdView.findViewById(R.id.contentad_advertiser);
        TextView contentad_call_to_action = (TextView) nativeContentAdView.findViewById(R.id.contentad_call_to_action);


        nativeContentAdView.setHeadlineView(nativeContentAdView.findViewById(R.id.contentad_headline));
        nativeContentAdView.setImageView(nativeContentAdView.findViewById(R.id.contentad_image));
        nativeContentAdView.setBodyView(nativeContentAdView.findViewById(R.id.contentad_body));
        nativeContentAdView.setCallToActionView(nativeContentAdView.findViewById(R.id.contentad_call_to_action));
        nativeContentAdView.setLogoView(nativeContentAdView.findViewById(R.id.contentad_logo));
        nativeContentAdView.setAdvertiserView(nativeContentAdView.findViewById(R.id.contentad_advertiser));
        ((TextView) nativeContentAdView.getHeadlineView()).setText(nativeContentAd.getHeadline());
        ((TextView) nativeContentAdView.getBodyView()).setText(nativeContentAd.getBody());
        ((TextView) nativeContentAdView.getCallToActionView()).setText(nativeContentAd.getCallToAction());
        ((TextView) nativeContentAdView.getAdvertiserView()).setText(nativeContentAd.getAdvertiser());
        List images = nativeContentAd.getImages();
        if (images.size() > 0) {
            ((ImageView) nativeContentAdView.getImageView()).setImageDrawable(((com.google.android.gms.ads.formats.NativeAd.Image) images.get(0)).getDrawable());
        }
        com.google.android.gms.ads.formats.NativeAd.Image logo = nativeContentAd.getLogo();
        if (logo == null) {
            nativeContentAdView.getLogoView().setVisibility(View.INVISIBLE);
        } else {
            ((ImageView) nativeContentAdView.getLogoView()).setImageDrawable(logo.getDrawable());
            nativeContentAdView.getLogoView().setVisibility(View.VISIBLE);
        }
        nativeContentAdView.setNativeAd(nativeContentAd);
    }

}

