package toolsinc.bank.pfbalancecheck.epfbalancecheck.splashexit.activity;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import androidx.appcompat.app.AppCompatActivity;
import android.view.WindowManager;
import android.widget.ImageView;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;
import com.u.securekeys.SecureEnvironment;

import toolsinc.bank.pfbalancecheck.epfbalancecheck.R;
import toolsinc.bank.pfbalancecheck.epfbalancecheck.splashexit.Utils.Common;

public class SplashActivity extends AppCompatActivity {

    private ImageView welcomeimg;
    private InterstitialAd mInterstitialAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_splash);

        MobileAds.initialize(this, SecureEnvironment.getString("admob_app_id"));

        initAdmobInterstitial(this);
        loadAdmobInterstitial();

        if (!Common.CheckNet(this)) {
            new Handler().postDelayed(new Runnable() {
                public void run() {
                    Intent i = new Intent(SplashActivity.this, StartActivity.class);
                    startActivity(i);
                    finish();
                }
            }, 3000);
        }

        init();

    }

    private void init() {
        welcomeimg = findViewById(R.id.welcomeimg);

        welcomeimg.animate()
                .translationY(welcomeimg.getHeight())
                .alpha(1.0f)
                .setDuration(1000)
                .setListener(new AnimatorListenerAdapter() {
                    @Override
                    public void onAnimationEnd(Animator animation) {
                        super.onAnimationEnd(animation);

                    }
                });
    }

    private void initAdmobInterstitial(Context context) {
        mInterstitialAd = new InterstitialAd(context);
        mInterstitialAd.setAdUnitId(SecureEnvironment.getString("sp_start_inter"));
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                Intent i = new Intent(SplashActivity.this, StartActivity.class);
                startActivity(i);
                finish();
                super.onAdClosed();
            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);
                new Handler().postDelayed(new Runnable() {
                    public void run() {
                        Intent i = new Intent(SplashActivity.this, StartActivity.class);
                        startActivity(i);
                        finish();
                    }
                }, 2000);
            }

            @Override
            public void onAdLeftApplication() {
                super.onAdLeftApplication();
            }

            @Override
            public void onAdOpened() {
                super.onAdOpened();
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
                showAdmobIntrestitial();
            }
        });
    }

    private void loadAdmobInterstitial() {
        if (mInterstitialAd != null) {
            mInterstitialAd.loadAd(new AdRequest.Builder().build());
        }
    }

    private void showAdmobIntrestitial() {
        if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
            mInterstitialAd.show();
        }
    }
}