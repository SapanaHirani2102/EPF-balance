package toolsinc.bank.pfbalancecheck.epfbalancecheck.helper;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.inputmethod.InputMethodManager;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import toolsinc.bank.pfbalancecheck.epfbalancecheck.model.Currency;

public class Utils {
    public static final String MMM_YY = "MMM yyyy";

    public static String getFormattedDate(Context context, String str, long j) {
        return new SimpleDateFormat(str, Locale.ENGLISH).format(new Date(j));
    }

    public static String getFormattedDate(String str, long j) {
        return getFormattedDate(null, str, j);
    }


    public static String getFormattedCurrency(Context context, double d) {
        return getFormatter(context).format(d);
    }

    public static String getFormattedCurrency(Context context, double d, int i) {
        DecimalFormat formatter = getFormatter(context);
        formatter.setMaximumFractionDigits(i);
        return formatter.format(d);
    }

    public static DecimalFormat getFormatter(Context context) {
        Currency currency = new Currency("India Rupee", "₹", "INR", new Locale("en", "IN"));
        Locale locale = currency.getLocale();
        if (locale == null) {
            locale = Locale.getDefault();
        }
        DecimalFormat decimalFormat = (DecimalFormat) NumberFormat.getCurrencyInstance(locale);
        DecimalFormatSymbols decimalFormatSymbols = decimalFormat.getDecimalFormatSymbols();
        decimalFormatSymbols.setCurrencySymbol(currency.getSymbol());
        decimalFormat.setDecimalFormatSymbols(decimalFormatSymbols);
        return decimalFormat;
    }

    public static void hideSoftKeyboard(Activity activity) {
        InputMethodManager inputMethodManager = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
        View currentFocus = activity.getCurrentFocus();
        if (currentFocus != null) {
            inputMethodManager.hideSoftInputFromWindow(currentFocus.getWindowToken(), 2);
        }
    }
}
