package toolsinc.bank.pfbalancecheck.epfbalancecheck.model;

import java.util.Locale;

public class Currency {
    private String code;
    private Locale locale;
    private String name;
    private String symbol;

    public Currency(String str, String str2, String str3, Locale locale) {
        this.name = str;
        this.symbol = str2;
        this.code = str3;
        this.locale = locale;
    }

    public String getName() {
        return this.name;
    }

    public String getSymbol() {
        return this.symbol;
    }

    public String getCode() {
        return this.code;
    }

    public Locale getLocale() {
        return this.locale;
    }
}
