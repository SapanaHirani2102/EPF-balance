package toolsinc.bank.pfbalancecheck.epfbalancecheck.splashexit.Utils;

import android.app.Application;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.facebook.ads.Ad;
import com.facebook.ads.AdChoicesView;
import com.facebook.ads.AdError;
import com.facebook.ads.AdIconView;
import com.facebook.ads.AudienceNetworkAds;
import com.facebook.ads.MediaView;
import com.facebook.ads.NativeAd;
import com.facebook.ads.NativeAdListener;
import com.onesignal.OneSignal;
import com.u.securekeys.SecureEnvironment;

import java.util.ArrayList;
import java.util.List;

import toolsinc.bank.pfbalancecheck.epfbalancecheck.R;

public class MyApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        OneSignal.startInit(this)
                .autoPromptLocation(false) // default call promptLocation later
                .inFocusDisplaying(OneSignal.OSInFocusDisplayOption.Notification)
                .unsubscribeWhenNotificationsAreDisabled(true)
                .filterOtherGCMReceivers(true)
                .init();


        AudienceNetworkAds.initialize(this);
        AudienceNetworkAds.isInAdsProcess(this);
    }

    @Override
    public void onTerminate() {
        super.onTerminate();
    }

}
