package toolsinc.bank.pfbalancecheck.epfbalancecheck.activity;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.u.securekeys.SecureEnvironment;

import toolsinc.bank.pfbalancecheck.epfbalancecheck.R;
import toolsinc.bank.pfbalancecheck.epfbalancecheck.adapter.OnlineAdapter;
import toolsinc.bank.pfbalancecheck.epfbalancecheck.splashexit.Utils.Common;

public class ActivityOnline extends AppCompatActivity {

    private InterstitialAd mInterstitialAdMob;

    private GridView gridView;
    public static int[] itemImage = {R.drawable.imagesub_01, R.drawable.imagesub_02, R.drawable.imagesub_03, R.drawable.imagesub_04, R.drawable.imagesub_05,
            R.drawable.imagesub_06, R.drawable.imagesub_07, R.drawable.imagesub_08, R.drawable.imagesub_09, R.drawable.imagesub_10, R.drawable.imagesub_11,
            R.drawable.imagesub_12, R.drawable.imagesub_13};
    public static String[] itemName = {"Check Your EPF", "Knowing the Claim Status", "Online Transfer Claims Portal (OTCP)",
            "Member Passbook", "Download Claim Form",
            "Multiple PF Accounts of an Employee", "E-Passbook",
            "Downloads", "Recruitments", "Tenders",
            "Right To Information", "Contact US", "Link UAN With Aadhar"};

    public static int[] itemImage1 = {R.drawable.imagesub_01, R.drawable.imagesub_02, R.drawable.imagesub_03, R.drawable.imagesub_04, R.drawable.imagesub_05,
            R.drawable.imagesub_06, R.drawable.imagesub_07, 0, R.drawable.imagesub_08, R.drawable.imagesub_09, R.drawable.imagesub_10, R.drawable.imagesub_11,
            R.drawable.imagesub_12, R.drawable.imagesub_13};
    public static String[] itemName1 = {"Check Your EPF", "Knowing the Claim Status", "Online Transfer Claims Portal (OTCP)",
            "Member Passbook", "Download Claim Form",
            "Multiple PF Accounts of an Employee", "E-Passbook", null,
            "Downloads", "Recruitments", "Tenders",
            "Right To Information", "Contact US", "Link UAN With Aadhar"};

    private Dialog dialog1;
    private boolean isAdview = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_online);
        ImageView ivBack = (ImageView) findViewById(R.id.ivBack);
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        FrameLayout adMobView = (FrameLayout) findViewById(R.id.adMobView);
        Common.NativeBanner(this, adMobView,"item_native");


        initAdmobFullAd(this);
        loadAdmobAd();

        dialog1 = new Dialog(ActivityOnline.this, R.style.DialogCustomTheme);
        dialog1.setContentView(R.layout.dialog_ad);
        dialog1.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        dialog1.getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);


        WindowManager.LayoutParams layoutParams1 = new WindowManager.LayoutParams();
        Window window = dialog1.getWindow();
        layoutParams1.copyFrom(window.getAttributes());
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int height = displayMetrics.heightPixels;
        int width = displayMetrics.widthPixels;

        layoutParams1.width = width;
        layoutParams1.height = height;
        window.setAttributes(layoutParams1);

        bindView();
    }

    private void bindView() {
        gridView = (GridView) findViewById(R.id.gridView);

        if (Common.CheckNet(this)) {
            gridView.setAdapter(new OnlineAdapter(ActivityOnline.this, itemImage1, itemName1));
        } else {
            gridView.setAdapter(new OnlineAdapter(ActivityOnline.this, itemImage, itemName));
        }

//        gridView.setAdapter(new OnlineAdapter(ActivityOnline.this, itemImage, itemName));
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent;
                if (Common.CheckNet(ActivityOnline.this)) {
                    if (position != 7) {
                        intent = new Intent(ActivityOnline.this, WebSearchActivity2.class);
                        intent.putExtra("position", position);
                        startActivityForResult(intent,100);
                    }
                } else {
                    intent = new Intent(ActivityOnline.this, WebSearchActivity2.class);
                    intent.putExtra("position", position);
                    startActivityForResult(intent,100);

                }
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && requestCode == 100) {
            if (isAdview) {
                showAdmobInterstitial();
                isAdview = false;
            } else {
                isAdview = true;
            }
        }

    }


    //Ad Start
    private void initAdmobFullAd(Context context) {
        mInterstitialAdMob = new InterstitialAd(context);
        mInterstitialAdMob.setAdUnitId(SecureEnvironment.getString("online_list_click_inter"));
        mInterstitialAdMob.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                loadAdmobAd();
            }

            @Override
            public void onAdLoaded() {

            }

            @Override
            public void onAdOpened() {
                //   super.onAdOpened();
            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);
            }
        });

    }

    private void loadAdmobAd() {
        if (mInterstitialAdMob != null && !mInterstitialAdMob.isLoaded()) {
            mInterstitialAdMob.loadAd(new AdRequest.Builder().build());
        }
    }

    private void showAdmobInterstitial() {
        if (mInterstitialAdMob != null && mInterstitialAdMob.isLoaded()) {
            mInterstitialAdMob.show();
        }
    }
    //Ad End


}
